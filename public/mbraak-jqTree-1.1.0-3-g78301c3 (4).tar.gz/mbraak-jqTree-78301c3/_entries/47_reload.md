---
title: reload
name: functions-reload
---

**function reload();**

Reload data.

{% highlight js %}
$('#tree1').tree('reload');
{% endhighlight %}
